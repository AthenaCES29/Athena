#include <stdio.h>

int main()
{
	printf("2 4");
	return 0;
}
