#include <stdio.h>

int main()
{
	printf("2 3");
	return 0;
}
